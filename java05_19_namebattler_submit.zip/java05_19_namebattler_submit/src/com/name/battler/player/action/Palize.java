package com.name.battler.player.action;

import com.name.battler.player.Player;

public interface Palize {
    
    // 麻痺状態にする
    void doPalizeState(Player player);
}
