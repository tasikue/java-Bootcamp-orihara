package com.name.battler.player.action;

import com.name.battler.player.Player;

public interface Attack {
    
    // 通常攻撃をする
    public int doNormalAttack(Player player);
}
