package com.name.battler.player.action;

public interface Thunder {
    
    // 電撃攻撃をする
    int doThunderAttack();
}
