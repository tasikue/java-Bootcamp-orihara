package com.name.battler.player.action;

import com.name.battler.player.Player;

public interface Poison {
    
    // 毒状態にする
    void doPoisonState(Player player);
}
