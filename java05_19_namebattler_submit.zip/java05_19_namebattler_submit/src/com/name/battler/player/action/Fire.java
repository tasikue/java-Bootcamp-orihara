package com.name.battler.player.action;

public interface Fire {
    
    // 火炎攻撃をする
    int doFireAttack();
}
