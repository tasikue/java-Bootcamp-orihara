package com.name.battler.player.action;

public interface Heel {
    
    // 回復をする
    void doHeel();
}
