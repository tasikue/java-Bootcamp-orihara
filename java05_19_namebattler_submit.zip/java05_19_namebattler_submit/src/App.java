import com.name.battler.GameProgress;

/**
 * 課題実行クラス
 */
public class App {

    public static void main(String[] args) throws Exception {

        GameProgress progress = new GameProgress();
        
        progress.progress();
    }
}
